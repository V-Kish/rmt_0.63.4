import { StyleSheet } from "react-native";

export const layout = StyleSheet.create({
    flewRow: { flex: 1 }
});