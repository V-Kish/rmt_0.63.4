import { StyleSheet } from "react-native";
import { CONSTANTS } from "./Variables";


export const homeScreen = StyleSheet.create(
    {
        container: {
            
        }
    }
);